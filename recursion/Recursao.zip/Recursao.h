class Recursao {
    public:
        string contagemCrescente(int p);
        int fatorial(int p);
        string contagemDecrescente(int p);
        string intervaloCrescente(int p, int q);
        string intervaloDecrescente(int p, int q);
        string paresCrescente(int p);
};